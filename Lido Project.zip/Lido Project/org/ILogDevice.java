public interface ILogDevice
{
 public void log(String str);
}